package com.example.bluetoothevprt23

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
